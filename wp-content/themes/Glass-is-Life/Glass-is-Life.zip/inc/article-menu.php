<div class="row">
    <div class="col-md-12">
        <div class="article-menu">
            <?php custom_main_nav( ); ?>
            <!-- <ul class="list-unstlyled list-inline">
                <li class="active">
                    <a href="taste.php">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/taste-tab.jpg"><div>TASTE</div>
                    </a>
                </li>
                <li><a href="quality.php"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/quality-tab.jpg"><div>QUALITY</div></a></li>
                <li><a href="sustainability.php"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/sustainability-tab.jpg"><div>SUSTAINABILITY</div></a></li>
                <li><a href="health.php"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/health-tab.jpg"><div>HEALTH</div></a></li>
            </ul> -->
        </div>
    </div>
</div> <!-- row article-menu -->